const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

import { useAuth } from "@/lib/AuthContext";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Bell } from "lucide-react";
import { Link } from "react-router-dom";

const PREFS = [
  { key: "new_posts", label: "Nuovi post", description: "Avvisami quando viene pubblicato un nuovo post" },
  { key: "new_comments", label: "Nuovi commenti", description: "Avvisami quando qualcuno commenta un post" },
  { key: "new_events", label: "Nuovi eventi", description: "Avvisami per nuovi eventi in programma" },
  { key: "new_jobs", label: "Offerte di lavoro", description: "Avvisami per nuove offerte di lavoro" },
  { key: "chat_messages", label: "Chat Live", description: "Avvisami per nuovi messaggi in chat" },
];

export default function NotificationSettings() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: prefsList = [] } = useQuery({
    queryKey: ["notif-prefs", user?.id],
    queryFn: () => db.entities.NotificationPreferences.filter({ user_id: user?.id }),
    enabled: !!user?.id,
  });

  const prefs = prefsList[0];

  const upsert = useMutation({
    mutationFn: async (data) => {
      if (prefs?.id) {
        return db.entities.NotificationPreferences.update(prefs.id, data);
      } else {
        return db.entities.NotificationPreferences.create({ user_id: user.id, ...data });
      }
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["notif-prefs", user?.id] }),
  });

  const toggle = (key) => {
    const current = prefs ? prefs[key] !== false : true;
    upsert.mutate({ [key]: !current });
  };

  return (
    <div className="pb-20 sm:pb-4">
      <Link to="/" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-4">
        <ArrowLeft className="h-4 w-4" /> Indietro
      </Link>
      <div className="flex items-center gap-2 mb-6">
        <Bell className="h-5 w-5 text-primary" />
        <h2 className="text-xl font-bold">Impostazioni Notifiche</h2>
      </div>
      <div className="space-y-4">
        {PREFS.map(({ key, label, description }) => {
          const enabled = prefs ? prefs[key] !== false : true;
          return (
            <div key={key} className="flex items-center justify-between p-4 bg-card border border-border rounded-xl">
              <div>
                <p className="font-medium text-sm">{label}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{description}</p>
              </div>
              <Switch checked={enabled} onCheckedChange={() => toggle(key)} />
            </div>
          );
        })}
      </div>
    </div>
  );
}