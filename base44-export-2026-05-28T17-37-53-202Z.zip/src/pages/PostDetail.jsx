const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useParams, Link, useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

import { ArrowLeft, Calendar, MapPin, Mail, Trash2, Loader2 } from "lucide-react";
import CommentsSection from "../components/CommentsSection";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/AuthContext";
import moment from "moment";

const catLabels = {
  informazione: "🔵 Informazione",
  consiglio: "💡 Consiglio",
  evento: "🎉 Evento",
  lavoro: "💼 Lavoro",
};

export default function PostDetail() {
  const { postId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: post, isLoading } = useQuery({
    queryKey: ["post", postId],
    queryFn: () => db.entities.Post.get(postId),
  });

  const deleteMutation = useMutation({
    mutationFn: () => db.entities.Post.delete(postId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["posts"] });
      navigate("/");
    },
  });

  if (isLoading) return <div className="flex justify-center py-12"><div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" /></div>;
  if (!post) return <p className="text-center py-12 text-muted-foreground">Post non trovato</p>;

  const isAuthor = user?.id === post.created_by_id;

  return (
    <div className="pb-20 sm:pb-4">
      <Link to="/" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-4">
        <ArrowLeft className="h-4 w-4" /> Indietro
      </Link>

      <span className="inline-block text-xs font-medium px-2 py-1 rounded-full bg-primary/10 text-primary mb-3">
        {catLabels[post.category]}
      </span>

      <h1 className="text-2xl font-bold text-foreground mb-2">{post.title}</h1>
      <p className="text-xs text-muted-foreground mb-4">{moment(post.created_date).format("D MMMM YYYY, HH:mm")}</p>

      {post.image_url && <img src={post.image_url} alt="" className="rounded-xl w-full max-h-64 object-cover mb-4" />}

      <div className="prose prose-sm max-w-none text-foreground whitespace-pre-wrap mb-6">{post.content}</div>

      <div className="space-y-2 text-sm text-muted-foreground">
        {post.event_date && (
          <div className="flex items-center gap-2"><Calendar className="h-4 w-4" />{moment(post.event_date).format("D MMMM YYYY")}</div>
        )}
        {post.location && (
          <div className="flex items-center gap-2"><MapPin className="h-4 w-4" />{post.location}</div>
        )}
        {post.contact && (
          <div className="flex items-center gap-2"><Mail className="h-4 w-4" />{post.contact}</div>
        )}
      </div>

      {isAuthor && (
        <Button variant="destructive" size="sm" className="mt-6" onClick={() => deleteMutation.mutate()} disabled={deleteMutation.isPending}>
          {deleteMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <Trash2 className="h-4 w-4 mr-1" />}
          Elimina
        </Button>
      )}

      <CommentsSection postId={postId} />
    </div>
  );
}