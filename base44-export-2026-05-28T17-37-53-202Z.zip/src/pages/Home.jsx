const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";

import PostCard from "../components/PostCard";
import { Search, MessageCircle } from "lucide-react";
import { Link } from "react-router-dom";
import { useLanguage } from "../hooks/useLanguage";
import { tr } from "../lib/translations";

export default function Home() {
  const [activeCategory, setActiveCategory] = useState("tutti");
  const [search, setSearch] = useState("");
  const [lang] = useLanguage();

  const categories = [
    { key: "tutti", label: tr(lang, "catAll") },
    { key: "informazione", label: tr(lang, "catInfo") },
    { key: "consiglio", label: tr(lang, "catTips") },
    { key: "evento", label: tr(lang, "catEvents") },
    { key: "lavoro", label: tr(lang, "catJobs") },
  ];

  const { data: posts = [], isLoading } = useQuery({
    queryKey: ["posts"],
    queryFn: () => db.entities.Post.list("-created_date", 100),
  });

  const filtered = posts.filter((p) => {
    if (activeCategory !== "tutti" && p.category !== activeCategory) return false;
    if (search && !p.title.toLowerCase().includes(search.toLowerCase()) && !p.content.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="space-y-4 pb-20 sm:pb-4">
      <Link
        to="/chat"
        className="flex items-center gap-3 w-full bg-red-600 text-white px-4 py-3 rounded-xl shadow-md hover:opacity-90 transition-opacity"
      >
        <MessageCircle className="h-5 w-5 shrink-0" />
        <div>
          <p className="font-semibold text-sm">{tr(lang, "chatLiveBanner")}</p>
          <p className="text-xs opacity-80">{tr(lang, "chatLiveSub")}</p>
        </div>
        <span className="ml-auto text-lg">→</span>
      </Link>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <input
          type="text"
          placeholder={tr(lang, "searchPlaceholder")}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-secondary border-0 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30"
        />
      </div>

      <div className="flex gap-2 overflow-x-auto no-scrollbar">
        {categories.map((c) => (
          <button
            key={c.key}
            onClick={() => setActiveCategory(c.key)}
            className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
              activeCategory === c.key
                ? "bg-primary text-primary-foreground"
                : "bg-secondary text-muted-foreground hover:text-foreground"
            }`}
          >
            {c.label}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="flex justify-center py-12">
          <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <p className="text-4xl mb-3">📭</p>
          <p className="text-sm text-muted-foreground">{tr(lang, "noPostsFound")}</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((post) => (
            <PostCard key={post.id} post={post} />
          ))}
        </div>
      )}
    </div>
  );
}