const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useMutation, useQueryClient } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Loader2 } from "lucide-react";
import { Link } from "react-router-dom";

export default function CreatePost() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [form, setForm] = useState({ title: "", content: "", category: "", event_date: "", location: "", contact: "", author_name: "" });

  const mutation = useMutation({
    mutationFn: (data) => db.entities.Post.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["posts"] });
      navigate("/");
    },
  });

  const update = (key, val) => setForm((f) => ({ ...f, [key]: val }));

  const handleSubmit = (e) => {
    e.preventDefault();
    const payload = { ...form };
    if (!payload.event_date) delete payload.event_date;
    if (!payload.location) delete payload.location;
    if (!payload.author_name) delete payload.author_name;
    if (!payload.contact) delete payload.contact;
    mutation.mutate(payload);
  };

  return (
    <div className="pb-20 sm:pb-4">
      <Link to="/" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-4">
        <ArrowLeft className="h-4 w-4" /> Indietro
      </Link>
      <h2 className="text-xl font-bold mb-6">Nuovo Post</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label>Categoria *</Label>
          <Select value={form.category} onValueChange={(v) => update("category", v)}>
            <SelectTrigger><SelectValue placeholder="Seleziona..." /></SelectTrigger>
            <SelectContent>
              <SelectItem value="informazione">🔵 Informazione</SelectItem>
              <SelectItem value="consiglio">💡 Consiglio</SelectItem>
              <SelectItem value="evento">🎉 Evento</SelectItem>
              <SelectItem value="lavoro">💼 Lavoro</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Titolo *</Label>
          <Input value={form.title} onChange={(e) => update("title", e.target.value)} placeholder="Es. Aperitivo italiano venerdì sera" />
        </div>
        <div>
          <Label>Contenuto *</Label>
          <Textarea rows={5} value={form.content} onChange={(e) => update("content", e.target.value)} placeholder="Scrivi i dettagli..." />
        </div>
        {(form.category === "evento" || form.category === "lavoro") && (
          <div>
            <Label>{form.category === "evento" ? "Data Evento" : "Scadenza"}</Label>
            <Input type="date" value={form.event_date} onChange={(e) => update("event_date", e.target.value)} />
          </div>
        )}
        <div>
          <Label>Luogo (opzionale)</Label>
          <Input value={form.location} onChange={(e) => update("location", e.target.value)} placeholder="Es. Brighton Centre" />
        </div>
        <div>
          <Label>Autore (opzionale)</Label>
          <Input value={form.author_name} onChange={(e) => update("author_name", e.target.value)} placeholder="Es. Mario Rossi" />
        </div>
        <div>
          <Label>Contatto (opzionale)</Label>
          <Input value={form.contact} onChange={(e) => update("contact", e.target.value)} placeholder="Email, telefono o link" />
        </div>
        <Button type="submit" className="w-full" disabled={!form.title || !form.content || !form.category || mutation.isPending}>
          {mutation.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
          Pubblica
        </Button>
      </form>
    </div>
  );
}