import { useState, useEffect } from "react";

export function useLanguage() {
  const [lang, setLangState] = useState(() => localStorage.getItem("app_lang") || "it");

  const setLang = (newLang) => {
    localStorage.setItem("app_lang", newLang);
    setLangState(newLang);
    window.dispatchEvent(new CustomEvent("langchange", { detail: newLang }));
  };

  useEffect(() => {
    const handler = (e) => setLangState(e.detail);
    window.addEventListener("langchange", handler);
    return () => window.removeEventListener("langchange", handler);
  }, []);

  return [lang, setLang];
}