const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { Outlet, Link, useLocation } from "react-router-dom";
import { Home, PlusCircle, LogOut, MessageCircle, Bell } from "lucide-react";

import { useLanguage } from "../hooks/useLanguage";
import { tr } from "../lib/translations";

export default function Layout() {
  const location = useLocation();
  const isActive = (path) => location.pathname === path;
  const [lang, setLang] = useLanguage();

  return (
    <div className="min-h-screen bg-background font-sans">
      <header className="sticky top-0 z-50 bg-black border-b border-neutral-800">
        <div className="max-w-2xl mx-auto px-4 py-3 flex items-center justify-between bg-[#1a959e]">
          <Link to="/" className="flex items-center gap-2">
            <img src="https://media.db.com/images/public/6a15fb53b83ee4ab37d352ee/3f7dca8b7_ITALIANI-A-BRIGHTON-E-HOVE-LOGO-2026.png" alt="Logo" className="h-14 object-contain" />
          </Link>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setLang(lang === "it" ? "en" : "it")}
              className="px-2 py-1 rounded-md border border-neutral-600 text-white text-[10px] font-semibold hover:bg-neutral-800 transition-colors">
              
              {lang === "it" ? "🇬🇧 EN" : "🇮🇹 IT"}
            </button>
            <Link
              to="/nuovo"
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-red-600 text-white text-sm font-medium hover:opacity-90 transition-opacity">
              
              <PlusCircle className="h-4 w-4" />
              <span className="hidden sm:inline">Pubblica</span>
            </Link>
            <a
              href="https://www.facebook.com/share/g/1b7EYs5JDx/"
              target="_blank"
              rel="noopener noreferrer"
              title="Seguici su Facebook"
              className="flex items-center gap-1 px-2 py-1.5 rounded-lg text-white hover:opacity-75 transition-opacity">
              
              <span className="text-[8px] font-bold tracking-wide">{tr(lang, "joinUs")}</span>
              <svg className="h-4 w-4 shrink-0" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" /></svg>
            </a>
            <Link to="/notifiche" className="p-2 rounded-lg text-white hover:opacity-75 transition-opacity relative">
              <Bell className="h-4 w-4" />
            </Link>
            <button
              onClick={() => db.auth.logout()}
              className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
              
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>

      </header>

      <main className="max-w-2xl mx-auto px-4 py-6">
        <Outlet />
      </main>

      <nav className="fixed bottom-0 inset-x-0 bg-card/80 backdrop-blur-lg border-t border-border sm:hidden">
        <div className="flex justify-around py-2">
          <Link to="/" className={`flex flex-col items-center gap-0.5 px-4 py-1 ${isActive("/") ? "text-primary" : "text-muted-foreground"}`}>
            <Home className="h-5 w-5" />
            <span className="text-[10px]">Home</span>
          </Link>
          <Link to="/nuovo" className={`flex flex-col items-center gap-0.5 px-4 py-1 ${isActive("/nuovo") ? "text-primary" : "text-muted-foreground"}`}>
            <PlusCircle className="h-5 w-5" />
            <span className="text-[10px]">Pubblica</span>
          </Link>
          <Link to="/chat" className={`flex flex-col items-center gap-0.5 px-4 py-1 relative ${isActive("/chat") ? "text-primary" : "text-muted-foreground"}`}>
            <MessageCircle className="h-5 w-5" />
            <span className="text-[10px]">Chat Live</span>
          </Link>
        </div>
      </nav>
    </div>);

}