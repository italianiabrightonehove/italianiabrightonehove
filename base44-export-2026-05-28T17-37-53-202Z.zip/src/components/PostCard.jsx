import { Link } from "react-router-dom";
import { Calendar, MapPin, Briefcase, Info, Lightbulb, PartyPopper } from "lucide-react";
import moment from "moment";

const categoryConfig = {
  informazione: { icon: Info, label: "Informazione", color: "bg-blue-100 text-blue-700" },
  consiglio: { icon: Lightbulb, label: "Consiglio", color: "bg-amber-100 text-amber-700" },
  evento: { icon: PartyPopper, label: "Evento", color: "bg-primary/10 text-primary" },
  lavoro: { icon: Briefcase, label: "Lavoro", color: "bg-red-100 text-red-700" },
};

export default function PostCard({ post }) {
  const cat = categoryConfig[post.category] || categoryConfig.informazione;
  const Icon = cat.icon;

  return (
    <Link
      to={`/post/${post.id}`}
      className="block bg-card rounded-xl border border-border p-4 hover:shadow-md transition-shadow"
    >
      <div className="flex items-start gap-3">
        <div className={`shrink-0 p-2 rounded-lg ${cat.color}`}>
          <Icon className="h-4 w-4" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 mb-1">
            <span className={`text-[11px] font-medium px-2 py-0.5 rounded-full ${cat.color}`}>{cat.label}</span>
            <span className="text-[11px] text-muted-foreground">{moment(post.created_date).fromNow()}</span>
          </div>
          <h3 className="font-semibold text-foreground text-sm leading-snug mb-1 line-clamp-2">{post.title}</h3>
          <p className="text-muted-foreground text-xs line-clamp-2">{post.content}</p>
          {(post.event_date || post.location) && (
            <div className="flex flex-wrap gap-3 mt-2 text-[11px] text-muted-foreground">
              {post.event_date && (
                <span className="inline-flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  {moment(post.event_date).format("D MMM YYYY")}
                </span>
              )}
              {post.location && (
                <span className="inline-flex items-center gap-1">
                  <MapPin className="h-3 w-3" />
                  {post.location}
                </span>
              )}
            </div>
          )}
        </div>
      </div>
      {post.image_url && (
        <img src={post.image_url} alt="" className="mt-3 rounded-lg w-full h-40 object-cover" />
      )}
    </Link>
  );
}