const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

import { useAuth } from "@/lib/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Send } from "lucide-react";
import moment from "moment";

export default function CommentsSection({ postId }) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [text, setText] = useState("");

  const { data: comments = [] } = useQuery({
    queryKey: ["comments", postId],
    queryFn: () => db.entities.Comment.filter({ post_id: postId }, "created_date", 100),
  });

  const addComment = useMutation({
    mutationFn: (data) => db.entities.Comment.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["comments", postId] });
      setText("");
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    addComment.mutate({ post_id: postId, text: text.trim(), author_name: user?.full_name || "Anonimo" });
  };

  return (
    <div className="mt-6 border-t border-border pt-4">
      <h3 className="font-semibold text-sm mb-3">Commenti ({comments.length})</h3>
      <div className="space-y-3 mb-4">
        {comments.length === 0 && (
          <p className="text-xs text-muted-foreground">Nessun commento ancora. Sii il primo!</p>
        )}
        {comments.map((c) => (
          <div key={c.id} className="bg-secondary rounded-lg px-3 py-2">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-medium text-foreground">{c.author_name}</span>
              <span className="text-[10px] text-muted-foreground">{moment(c.created_date).fromNow()}</span>
            </div>
            <p className="text-xs text-foreground">{c.text}</p>
          </div>
        ))}
      </div>
      <form onSubmit={handleSubmit} className="flex gap-2">
        <Input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Scrivi un commento..."
          className="flex-1 text-sm"
        />
        <Button type="submit" size="icon" disabled={!text.trim() || addComment.isPending}>
          <Send className="h-4 w-4" />
        </Button>
      </form>
    </div>
  );
}